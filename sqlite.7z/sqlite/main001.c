#include <stdio.h>
#include <sqlite3.h>

#ifdef __TINYC__
#pragma comment(lib, "sqlite3") 
#endif


int main(int argc, char** argv[])
{

  printf("ver: %d\n",sqlite3_libversion_number());
  printf("ver: %s\n", sqlite3_libversion());
  
  sqlite3 *db;
  sqlite3_stmt *res;
  
  int rc = sqlite3_open(":memory:", &db);
  
  if (rc != SQLITE_OK) 
  {
    fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
    sqlite3_close(db);
    
    return 1;
  }

  // Перед выполнением инструкции SQL ее необходимо сначала скомпилировать в байт-код 
  // Третий параметр — это максимальная длина инструкции SQL, измеряемая в байтах. 
  // Передача -1 приводит к считыванию строки SQL до первого нулевого терминатора, 
  // который является концом строки здесь.
  
  rc = sqlite3_prepare_v2(db, "SELECT SQLITE_VERSION()", -1, &res, 0);
  
  if (rc != SQLITE_OK)
  {
    fprintf(stderr, "Failed to fetch data %s\n", sqlite3_errmsg(db));
    sqlite3_close(db);
    
    return 1;
  }
    
  // Наша инструкция SQL возвращает только одну строку данных, поэтому мы вызываем эту функцию только один раз.  
  rc = sqlite3_step(res);
  
  if (rc == SQLITE_ROW) 
  {
    
    printf("%s\n", sqlite3_column_text(res,0));
    
  }
  
sqlite3_finalize(res);
sqlite3_close(db);

return 0;
}

