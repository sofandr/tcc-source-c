#include <stdio.h>
#include <sqlite3.h>

#ifdef __TINYC__
#pragma comment(lib, "sqlite3") 
#endif


int main(int argc, char** argv[])
{

  printf("version sqlite: %s\n", sqlite3_libversion());
  
  sqlite3 *db;
  char *err_msg = 0;
  
  int rc = sqlite3_open("test.db", &db);
  
  if (rc != SQLITE_OK) 
  {
    fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
    sqlite3_close(db);
    
    return 1;
  }




  char *sql = "DROP TABLE IF EXISTS Cars;"
              "CREATE TABLE Cars (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, Name TEXT, Price INT);"
              "INSERT INTO  Cars (Name, Price) VALUES('Audi', 52642);"
              "INSERT INTO  Cars (Name, Price) VALUES('Mercedes', 52642);"
              "INSERT INTO  Cars (Name, Price) VALUES('Lada', 10000);"
              "INSERT INTO  Cars (Name, Price) VALUES('Belarus Car', 80000);";
                
  printf("sql: %s\n", sql);
  rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
  
  
  
  if (rc != SQLITE_OK)
  {
    fprintf(stderr, "SQL error:  %s\n", err_msg);
    sqlite3_free(err_msg);
    sqlite3_close(db);
    
    return 1;
  }
    

  
  
sqlite3_close(db);

return 0;
}

