// Мы вставили некоторые данные в базу данных. В следующем примере мы извлекаем данные из базы данных. test.db

/*
В примере в качестве заполнителя используется вопросительный знак (?), который позже заменено фактическим значением.

char *sql = "SELECT Id, Name FROM Cars WHERE Id = ?";
Вопросительный знак используется для предоставления идентификатора SQL-запросу.

rc = sqlite3_prepare_v2(db, sql, -1, &res, 0);
Функция компилирует SQL-запрос.sqlite3_prepare_v2()

sqlite3_bind_int(res, 1, 3);
Привязывает целое значение к подготовленному утверждение. 
Заполнитель заменяется целочисленным значением 3. 
Вторым параметром функции является индекс задаваемого параметра SQL 
и третий параметр — это значение для привязки к параметру.sqlite3_bind_int()

int step = sqlite3_step(res);
Функция вычисляет инструкцию SQL.sqlite3_step()

if (step == SQLITE_ROW) {
    
    printf("%s: ", sqlite3_column_text(res, 0));
    printf("%s\n", sqlite3_column_text(res, 1));
    
} 
*/

#include <stdio.h>
#include <sqlite3.h>

#ifdef __TINYC__
#pragma comment(lib, "sqlite3") 
#endif





int main(int argc, char** argv[])
{

    
 sqlite3 *db;
 char *err_msg = 0;
 sqlite3_stmt *res;
 
 int rc = sqlite3_open("test.db", &db);
 
 if (rc != SQLITE_OK) {
     
     fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
     sqlite3_close(db);
     
     return 1;
 }
 
 char *sql = "SELECT Id, Name FROM Cars WHERE Id = ?";
     
 rc = sqlite3_prepare_v2(db, sql, -1, &res, 0);
 
 if (rc == SQLITE_OK) {
     
     sqlite3_bind_int(res, 1, 3);
 } else {
     
     fprintf(stderr, "Failed to execute statement: %s\n", sqlite3_errmsg(db));
 }
 
 int step = sqlite3_step(res);
 
 if (step == SQLITE_ROW) {
     
     printf("%s: ", sqlite3_column_text(res, 0));
     printf("%s\n", sqlite3_column_text(res, 1));
     
 } 

 sqlite3_finalize(res);
 sqlite3_close(db);
 
 return 0;


}




