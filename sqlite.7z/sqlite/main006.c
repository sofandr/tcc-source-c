// Во втором примере используются параметризованные операторы с именованные заполнители.

#include <stdio.h>
#include <sqlite3.h>

#ifdef __TINYC__
#pragma comment(lib, "sqlite3") 
#endif


int main(int argc, char** argv[])
{

 sqlite3 *db;
 char *err_msg = 0;
 sqlite3_stmt *res;
 
 int rc = sqlite3_open("test.db", &db);
 
 if (rc != SQLITE_OK) {
     
     fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
     sqlite3_close(db);
     
     return 1;
 }

//Именованные заполнители имеют префикс с двоеточием (:) персонаж или символ at-sign (@). 

 char *sql = "SELECT Id, Name FROM Cars WHERE Id = @id";
     
 rc = sqlite3_prepare_v2(db, sql, -1, &res, 0);
 
 if (rc == SQLITE_OK) {
     
     int idx = sqlite3_bind_parameter_index(res, "@id");
     int value = 4;
     sqlite3_bind_int(res, idx, value);
     
 } else {
     
     fprintf(stderr, "Failed to execute statement: %s\n", sqlite3_errmsg(db));
 }
 
 int step = sqlite3_step(res);
 
 if (step == SQLITE_ROW) {
     
     printf("%s: ", sqlite3_column_text(res, 0));
     printf("%s\n", sqlite3_column_text(res, 1));
     
 } 

 sqlite3_finalize(res);
 sqlite3_close(db);
 
 return 0;

}




